# WAITER
Fájlban tároljuk, hogy egy londoni pincér mekkora összegeket helyezett el a pénztárcájában az elmúlt órában. Amikor kivett a tárcából pénzt, azt negatív számmal jeleztük. A pincérünk elég ügyetlen és slampos, így soha nem kap borravalót.

3

8

10

19.35

-6

5.1

9

20

#G a. Olvasd be az adatokat egy osszegek nevű listába!

#G b. Volt-e olyan, hogy a pincér vásárolt valamit, vagy mindig csak neki fizettek?

#M c. Ha az óra elején üres a pénztárcája, mennyi van benne az óra végén?

#G d. Hány alkalommal kapott biztosan pennyt is, nem csak fontot?

#G e. Hány pennyt kapott összesen (feltételezve, hogy csak azt fizették pennyben, amit nem lehet fontban)?

#G f. Hány esetben kapott legalább öt fontot?

#G g. Mi állt a legnagyobb számlán, amit fizettek a pincérnél?

#G h. Ha az óra elején már volt 8 font 23 penny a tárcájában, mennyi pénz volt benne az óra végén?

#G i. Hányadik vendég fizetett 9 fontot?

#M j. Ha volt olyan vendég, aki tíz fontnál többet fizetett, akkor mondjuk meg, hogy hányadik vendég volt az első ilyen!

#M k. Ha volt olyan vendég, aki tíz fontnál többet fizetett, akkor mondjuk meg, hogy hányadik vendég volt az utolsó ilyen!

#M l. Volt-e olyan vendég, akinek módjában állt csupa ötfontossal kiegyenlíteni a számlát?

#M m. Ha a főnöke minden vendég után fél fontot ad pincérünknek fizetésül, mekkora bevétellel zárta az órát?
